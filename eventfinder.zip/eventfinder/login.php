<?php

session_start();
$conn = mysqli_connect('localhost', 'root', '' , 'user') or die ('Unable to connect');

?>
<!-- checks if username and password are stored in database -->
<?php
    if (isset($_POST['login'])){
        $Username = $_POST['username'];
        $Pass = $_POST['pass'];

    $select = mysqli_query($conn," SELECT * FROM users WHERE username = '$Username' AND password = '$Pass' ");
    $row  = mysqli_fetch_array($select);

    if(is_array($row)) {
        $_SESSION["username"] = $row['username'];
        $_SESSION["pass"] = $row['pass'];
    }   else {
        echo '<script type = "text/javascript">';
        echo 'alert("Invalid Username or Password!");';
        echo 'window.location.href = "login.php" ';
        echo '</script>';
    }
    }
    if(isset($_SESSION["username"])){
        header("Location:admin.php");
    }
?>


<?php include("includes/a_config.php");?>


<!DOCTYPE html>
<html lang="en">
<head>
    <script src="js/fontawesome.js"></script>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/login.css">
    
</head>
<body>

<?php include("includes/navlogin.php");?>
<h2>Login </h2>
    <!-- user login form -->
    <form method="post">
    
      <div class="container">
        <label for="username"><b>Username</b></label>
        <input type="text" placeholder="Enter Username" name="username" required>
    
        <label for="password"><b>Password</b></label>
        <input type="password" placeholder="Enter Password" name="pass" required>
            
        <button type="submit" name="login">Login</button>
        <label>
          
      </div>
    
     
    </form>

    <?php include("includes/footer.php");?>