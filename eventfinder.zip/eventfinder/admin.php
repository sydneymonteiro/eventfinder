<?php
session_start();
?>

<?php include("includes/a_config.php");?>
<!DOCTYPE html>
<html lang="en">
<head>
    <script src="js/fontawesome.js"></script>
    <script src="js/addevent.js"></script>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/sidebarstyles.css">
    <link rel="stylesheet" href="css/registration.css">
    <link rel="stylesheet" href="css/tablestyle.css">
</head>
<body>
   

<?php include("includes/navlogin.php");?>
<div class="wrapper">

    <div class="sidebar">
        <h2>Admin Panel    <i class="fas fa-users-cog"></i></h2>
        <ul>
            <li><a class="active" href="#"><i class="fas fa-futbol"></i>Events</a></li>
            <li><a href="addCategory.php"><i class="fas fa-plus"></i>Event Category</a></li>
            
           
        </ul> 
      
    </div>
    <div class="main_content">
        <div class="header"><i class="fas fa-plus"></i><button onclick="window.location.href='admin.php';">Add Event</button></div>  
        <div class="info">
    
      


        <div class="container"> <!-- form for event registration -->
  <form action="includes/addevent.php" method="POST" enctype="multipart/form-data" name = "addevent" onsubmit="return validateForm()">
    <label for="ename">Event Name</label>
    <input type="text" id="name" name="ename" placeholder="Event name..." value="<?php echo $ename;?>">

    <label for="description">description</label>
    <textarea id="description" name="description" placeholder="Event description.." value="<?php echo $description;?>" style="height:200px"></textarea>

    <label for="date"></label>
    <input type="date" id="date" name="date" value="<?php echo $date;?>">
</br>

    <label for="eventc">Event Category</label>

      <!-- dropdown list with category from the database -->
    <?php
   $mysqli = NEW MySQli('localhost', 'root', '' , 'user');
   $resulteventc = $mysqli->query("SELECT type FROM eventCategory");
?>

    <select id="eventc" name="eventc" value="<?php echo $eventc;?>">

      <?php
      while($rows =$resulteventc->fetch_assoc()){
          $eventc = $rows['type'];
          echo"<option value='$eventc'>$eventc</option>";
      }
      $mysqli -> close();
      ?>
    </select>

 

    <input type="radio" id="enable" name="state" value ="enable" >
  <label for="enable">Enable</label>
  <input type="radio" id="disable" name="state" value="disbale" >
  <label for="disable">Disable</label><br> 
  <input type="checkbox" id="featured" name="featured" value ="featured" >
  <label for="enable">Featured</label><br>

  <input type ="file" name="image" id ="image"/>

   

    <input type="submit" value="Add">
  </form>
  <br>
<br>
<br>

  <div class ="table-responsive">
 <!-- displays table with all events entered from the database -->
<?php
   $connection = mysqli_connect('localhost', 'root', '' , 'user');
    $query="SELECT * From events";
    $query_run = mysqli_query($connection,$query);
?>
  <table class="table table-bordered" id="dataTable" width="50%" cellspaceing="0">
      <thead>
          <tr>
              <th>Id</th>
              <th>ename</th>
              <th>description</th>
              <th> data</th> 
              <th>eventc</th>
              <th>state</th>
              <th>featured</th>
              <th>image</th>
              <th>Edit</th>
              <th>Delete</th>
</tr>
</thead>
<tbody>
  <?php
  if(mysqli_num_rows($query_run)>0){
      while($row=mysqli_fetch_assoc($query_run))
      {
    ?>

 
<tr>
              <td><?php echo $row['id'];?></td>
              <td><?php echo $row['ename'];?></td>
              <td><?php echo $row['description'];?></td>
              <td><?php echo $row['date'];?></td>
              <td><?php echo $row['eventc'];?></td>
              <td><?php echo $row['state'];?></td>
              <td><?php echo $row['featured'];?></td>
             <td> <img src="data:image/jpeg;base64,<?php echo base64_encode($row['image'] ); ?>" width ="50 " height = "50" /> </td>
             

              
              <td> <button onclick="window.location.href ='updatevent.php?edit=<?php echo $row['id'];?>';">Edit</button></td><!-- sends event id to edit  -->
              <td><button onclick="window.location.href ='deletevent.php?delete=<?php echo $row['id'];?>';">Delete</button></td><!-- sends event id to delete -->
             
    

              
</tr>
<?php
      }
  }
  else{
      echo "no record found";
  }
  mysqli_close($connection);
  ?>

</tbody>
</table>
</div>







</div>

          
      </div>
    </div>

</div>


<?php include("includes/footer.php");?>