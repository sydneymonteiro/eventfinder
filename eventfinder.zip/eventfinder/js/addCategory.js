
function validateForm(){
    let x = document.forms["addCategory"]["eventc"].value;
    if(x==""){   
        alert("Fill in the Event Category");   // if category field if empty displays alert message
        return false;
    }

}