<?php

 $conn = mysqli_connect('localhost', 'root', '' , 'user') or die ('Unable to connect');
 $eventc = mysqli_real_escape_string($conn, $_REQUEST['eventc']); //gets the updated value from form
   // gets the id from the url and updates eventCategory with the id
 if (isset($_GET['edit'])){
     $id = $_GET['edit'];
     
     $sql =  ("UPDATE eventCategory SET type='$eventc' WHERE id = $id");
 }

 if(mysqli_query($conn, $sql)){
    header("Location:../addCategory.php");
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($conn);
}

mysqli_close($conn);
?>