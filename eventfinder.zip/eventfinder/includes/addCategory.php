<?php
$conn = mysqli_connect('localhost', 'root', '' , 'user') or die ('Unable to connect');

$eventc = mysqli_real_escape_string($conn, $_REQUEST['eventc']);// gets the value from textbox and initialize to $eventc


$sql = "INSERT INTO eventCategory (type) VALUES ('$eventc')";// inserts the the value to type into the database
if(mysqli_query($conn, $sql)){ //if sucussfull head to addCategory.php
    header("Location:../addCategory.php");
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($conn);//displays error
}
mysqli_close($conn);
?>