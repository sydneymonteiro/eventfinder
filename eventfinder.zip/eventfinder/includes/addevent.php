

<?php
$conn = mysqli_connect('localhost', 'root', '' , 'user') or die ('Unable to connect');
// gets the all value from the form and assigns to a corrosponding variable
$ename = mysqli_real_escape_string($conn, $_REQUEST['ename']);
$description = mysqli_real_escape_string($conn, $_REQUEST['description']);
$date = mysqli_real_escape_string($conn, $_REQUEST['date']);
$eventc = mysqli_real_escape_string($conn, $_REQUEST['eventc']);
$state = mysqli_real_escape_string($conn, $_REQUEST['state']);

$featured = mysqli_real_escape_string($conn, $_REQUEST['featured']);

$file = addslashes(file_get_contents($_FILES["image"]["tmp_name"]));


// inserts the values into table events
$sql = "INSERT INTO events ( ename , description , date, eventc,state,featured,image) VALUES ('$ename','$description','$date','$eventc','$state','$featured','$file')";
if(mysqli_query($conn, $sql)){
    header("Location:../admin.php");
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($conn);
}

mysqli_close($conn);

?>





