
<?php
session_start();
?>
<?php
if(!isset($_SESSION['username'])){// check if not session exits
	?>

<nav>
    <input type="checkbox" id="check">
    <label for="check" class="checkbtn">
      <i class="fas fa-bars"></i>
    </label>
    <label class="logo">EventFinder</label>
    <ul class="nav nav-pills">
	  <li class="nav-item">
	    <a class="nav-link <?php if ($CURRENT_PAGE == "Index") {?>active<?php }?>" href="index.php">Home</a> 
	  </li>
	  <li class="nav-item">
	    <a class="nav-link <?php if ($CURRENT_PAGE == "Events") {?>active<?php }?>" href="events.php">Events</a>
	  </li>
	  <li class="nav-item">
	    <a class="nav-link <?php if ($CURRENT_PAGE == "Login") {?>active<?php }?>" href="login.php">Login</a>
	  </li>
	</ul>
  </nav>
  <?php
}else{ // if file field contains image
	?>
<nav>
    <input type="checkbox" id="check">
    <label for="check" class="checkbtn">
      <i class="fas fa-bars"></i>
    </label>
    <label class="logo">EventFinder</label>
    <ul class="nav nav-pills">
	  <li class="nav-item">
	    <a class="nav-link <?php if ($CURRENT_PAGE == "Index") {?>active<?php }?>" href="index.php">Home</a>
	  </li>
	  <li class="nav-item">
	    <a class="nav-link <?php if ($CURRENT_PAGE == "Events") {?>active<?php }?>" href="events.php">Events</a>
	  </li>
	  <li class="nav-item">
	    <a class="nav-link <?php if ($CURRENT_PAGE == "Admin") {?>active<?php }?>" href="admin.php">Admin</a>
	  </li>
      <li class="nav-item">
	    <a class="nav-link <?php if ($CURRENT_PAGE == "Logout") {?>active<?php }?>" href="logout.php">Logout</a>
	  </li>
	</ul>
  </nav>
  <?php
}
?>




