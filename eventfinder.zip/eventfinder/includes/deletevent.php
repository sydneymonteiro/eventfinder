<?php
$conn = mysqli_connect('localhost', 'root', '' , 'user') or die ('Unable to connect');
 // gets the id from the url and deletes event with the id
if (isset($_GET['delete'])){
    $id = $_GET['delete'];
    $conn->query("DELETE FROM events WHERE id=$id");
    header("location: ../admin.php");
}

mysqli_close($conn);
?>

