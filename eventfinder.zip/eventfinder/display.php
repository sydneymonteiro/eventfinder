<?php include("includes/a_config.php");?>
<!DOCTYPE html>
<html lang="en">
<head>
    <script src="js/fontawesome.js"></script>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Events</title>
    <link rel="stylesheet" href="css/style.css">
    
</head>
<style>
.card {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  max-width: 800px;
  margin: auto;
  text-align: left;
  font-family: arial;
}

.type {
  color: grey;
  font-size: 22px;
}
.image {
    text-align: center;
}

.card button {
  border: none;
  outline: 0;
  padding: 12px;
  color: white;
  background-color: #000;
  text-align: center;
  cursor: pointer;
  width: 100%;
  font-size: 18px;
}

.card button:hover {
  opacity: 0.7;
}
</style>

<body>


<?php include("includes/navlogin.php");?>
<br>
<br>
<br>
<!-- gets the event id from the url and display event info -->
<?php
$conn = mysqli_connect('localhost', 'root', '' , 'user') or die ('Unable to connect');

if (isset($_GET['display'])){
    $id = $_GET['display'];

    $result = $conn->query("SELECT * FROM events WHERE id =$id ") or die($conn->error());
    
        $row =$result->fetch_array();
        $ename = $row['ename'];
        $description = $row['description'];
        $date = $row['date'];
        $eventc = $row['eventc'];
        $state = $row['state'];
        $featured = $row['featured'];
        $image = $row['image'];
       
    }
?>
<div class="card">
    <div class ="image">
  <img src="data:image/jpeg;base64,<?php echo base64_encode($image ); ?>" alt="Event_photo" width ="400 " height = "300" ><!-- gets events image from database with the id  -->
</div>
  <h1>Event name:<?php echo $ename;?></h1><!-- gets events name  database with the id  -->
  <p class="type">Category:<?php echo $eventc ?></p>
  <p class="type">Date:<?php echo $date ?></p><!-- gets events category and date from database with the id  -->
  <p>Details:<?php echo $description ?></p><!-- gets events descrpition from database with the id  -->
  <p><button onclick="window.location.href='index.php';">Back</button></p>
</div>





<?php include("includes/footer.php");?>