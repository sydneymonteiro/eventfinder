<?php
session_start();
?>

<?php include("includes/a_config.php");?>
<!DOCTYPE html>
<html lang="en">
<head>
    <script src="js/fontawesome.js"></script>
    <script src="js/addCategory.js"></script>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/sidebarstyles.css">
    <link rel="stylesheet" href="css/tablestyle.css">
    <link rel="stylesheet" href="css/registration.css">
</head>
<body>

<?php include("includes/navlogin.php");?>
<div class="wrapper">

<div class="sidebar">
        <h2>Admin Panel    <i class="fas fa-users-cog"></i></h2>
        <ul>
            <li><a  href="admin.php"><i class="fas fa-futbol"></i>Events</a></li>
            <li><a class="active" href="addCategory.php"><i class="fas fa-plus"></i>Event Category</a></li>
            
           
        </ul> 
      
    </div>

<!-- gets the id from urls to update the category -->
    <?php
$conn = mysqli_connect('localhost', 'root', '' , 'user') or die ('Unable to connect');

if (isset($_GET['edit'])){
    $id = $_GET['edit'];
    
    $result = $conn->query("SELECT * FROM eventCategory WHERE id = $id ") ;
    
        $row =$result->fetch_array();
        $eventc = $row['type'];  
       
    }
  

?>

    <div class="main_content">
        <div class="header"><i class="fas fa-plus"></i><button onclick="window.location.href='addCategory.php';">Add Category</button></div>  
        <div class="addevent">
        <div class="container">
        <form action = "includes/updatec.php?edit=<?php echo $row['id'];?>" method="post" name = "addCategory" onsubmit="return validateForm()">
        
  <label for="eventc">Event Category:</label>
  <input type="text" id="eventc" name="eventc" value ="<?php echo $eventc ?>"><!--  gets the category from the database -->
  <input type="submit" value="update"><!-- saves the updated category into the row with same id  -->
</form>
</div>
<br>
<br>
<br>
<br>


<!--  displays the updated table from the database-->

  <div class ="table-responsive">

  <?php
     $connection = mysqli_connect('localhost', 'root', '' , 'user');
      $query="SELECT * From eventCategory";
      $query_run = mysqli_query($connection,$query);
  ?>
    <table class="table table-bordered" id="dataTable" width="50%" cellspaceing="0">
        <thead>
            <tr>
                <th>Id</th>
                <th>Type</th>
                <th>Edit</th>
                <th>Delete</th>
</tr>
</thead>
<tbody>
    <?php
    if(mysqli_num_rows($query_run)>0){
        while($row=mysqli_fetch_assoc($query_run))
        {
      ?>

   
<tr>
                <td><?php echo $row['id'];?></td>
                <td><?php echo $row['type'];?></td>

                <td> <button onclick="window.location.href ='updateCategory.php?edit=<?php echo $row['id'];?>';">Edit</button></td><!-- send id to update the category -->
              <td> <button onclick="window.location.href ='deletec.php?delete=<?php echo $row['id'];?>';">Delete</button> </td><!-- send id to delete from database -->
</tr>
<?php
        }
    }
    else{
        echo "no record found";
    }
    mysqli_close($connection);
    ?>

</tbody>
</table>
</div>



        </div>
    </div>


    



</div>



<?php include("includes/footer.php");?>