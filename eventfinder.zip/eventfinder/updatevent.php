<?php
session_start();
?>

<?php include("includes/a_config.php");?>
<!DOCTYPE html>
<html lang="en">
<head>
    <script src="js/fontawesome.js"></script>
    <script src="js/upevent.js"></script>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/sidebarstyles.css">
    <link rel="stylesheet" href="css/registration.css">
    <link rel="stylesheet" href="css/tablestyle.css">
</head>
<body>
   
<?php include("includes/navlogin.php");?>
<div class="wrapper">

    <div class="sidebar">
        <h2>Admin Panel    <i class="fas fa-users-cog"></i></h2>
        <ul>
            <li><a class="active" href="#"><i class="fas fa-futbol"></i>Events</a></li>
            <li><a href="addCategory.php"><i class="fas fa-plus"></i>Event Category</a></li>
            
           
        </ul> 
      
    </div>
    <div class="main_content">
        <div class="header"><i class="fas fa-plus"></i><button onclick="window.location.href='admin.php';" >Add Event</button></div>  
        <div class="info">
      <!-- gets the id from the url to upadate the  event  -->
        <?php
$conn = mysqli_connect('localhost', 'root', '' , 'user') or die ('Unable to connect');

if (isset($_GET['edit'])){
    $id = $_GET['edit'];
    
    $result = $conn->query("SELECT * FROM events WHERE id =$id ") or die($conn->error());
    
        $row =$result->fetch_array();
        $ename = $row['ename'];
        $description = $row['description'];
        $date = $row['date'];
        $eventc = $row['eventc'];
        $state = $row['state'];
        $featured = $row['featured'];
        $image = $row['image'];
       
    }



?>

        <div class="container">
  <form action="includes/updatevent.php?edit=<?php echo $row['id'];?>" method="POST" enctype="multipart/form-data" name = "upevent" onsubmit="return validateForm()">
    <label for="ename">Event Name</label>
    <input type="text" id="name" name="ename" placeholder="Event name..." value="<?php echo $ename;?>"><!-- gets events name  into textbox from database with the id  -->

    <label for="description">description</label>
    <textarea id="description" name="description" placeholder="Event description.." style="height:200px"><?php echo $description;?></textarea><!-- gets events descrpition into textarea from database with the id  -->

    <label for="date"></label>
    <input type="date" id="date" name="date" value="<?php echo $date;?>"><!-- gets events date  into date field from database with the id  -->
</br>

    <label for="eventc">Event Category</label>

   <!-- dropdown list of category from database -->
    <?php
   $mysqli = NEW MySQli('localhost', 'root', '' , 'user');
   $resulteventc = $mysqli->query("SELECT type FROM eventCategory");
?>

    <select id="eventc" name="eventc" >
       <option value ="<?php echo $eventc;?>"><?php echo $eventc;?></option>
      <?php
      while($rows =$resulteventc->fetch_assoc()){
          $eventc = $rows['type'];
          echo"<option value='$eventc'>$eventc</option>";
      }
      ?>
    </select>



    <input type="radio" id="enable" name="state" value ="enable" <?php if ($state =='enable') echo'checked=checked "';?>  ><!-- gets events state either enable or disable and sets te radio button from database with the id  -->
  <label for="enable">Enable</label>
  <input type="radio" id="disable" name="state" value="disable" <?php if ($state =='disable') echo'checked=checked "';?>>
  <label for="disable">Disable</label><br>
  <input type="checkbox" id="featured" name="featured" value ="featured" <?php if ($featured =='featured') echo'checked=checked "';?> ><!-- checks featured is it was marked as featured -->
  <label for="enable">Featured</label><br>

  <input type ="file" name="image" id ="image"/>
  <img src="data:image/jpeg;base64,<?php echo base64_encode($image ); ?>" width ="50 " height = "50" /> <!-- display small image of pervious saved image -->
   

    <input type="submit" value="Update"><!-- updates event database with the id  -->
  </form>
  <br>
<br>
<br>
<!-- displays the updated evnts -->

  <div class ="table-responsive">

<?php
   $connection = mysqli_connect('localhost', 'root', '' , 'user');
    $query="SELECT * From events";
    $query_run = mysqli_query($connection,$query);
?>
  <table class="table table-bordered" id="dataTable" width="50%" cellspaceing="0">
      <thead>
          <tr>
              <th>Id</th>
              <th>ename</th>
              <th>description</th>
              <th>data</th> 
              <th>eventc</th>
              <th>state</th>
              <th>featured</th>
              <th>image</th>
              <th>Edit</th>
              <th>Delete</th>
</tr>
</thead>
<tbody>
  <?php
  if(mysqli_num_rows($query_run)>0){
      while($row=mysqli_fetch_assoc($query_run))
      {
    ?>

 
<tr>
              <td><?php echo $row['id'];?></td>
              <td><?php echo $row['ename'];?></td>
              <td><?php echo $row['description'];?></td>
              <td><?php echo $row['date'];?></td>
              <td><?php echo $row['eventc'];?></td>
              <td><?php echo $row['state'];?></td>

             <td><?php echo $row['featured'];?></td>
             <td> <img src="data:image/jpeg;base64,<?php echo base64_encode($row['image'] ); ?>" width ="50 " height = "50" /> </td>

              
              <td> <button onclick="window.location.href ='updatevent.php?edit=<?php echo $row['id'];?>';">Edit</button></td><!-- sends id to update events from the database -->
              <td> <button onclick="window.location.href ='deletevent.php?delete=<?php echo $row['id'];?>';">Delete</button></td><!--  sends id to delete from the database-->
             
    

              
</tr>
<?php
      }
  }
  else{
      echo "no record found";
  }
  mysqli_close($connection);s
  ?>

</tbody>
</table>
</div>







</div>

          
      </div>
    </div>

</div>


<?php include("includes/footer.php");?>